CREATE DATABASE  IF NOT EXISTS `logistica` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `logistica`;
-- MySQL dump 10.13  Distrib 5.5.49, for debian-linux-gnu (i686)
--
-- Host: 127.0.0.1    Database: logistica
-- ------------------------------------------------------
-- Server version	5.5.49-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('admin','user','logistica') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user',
  `language` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Chuda','chudacontreras@gmail.com','$2y$10$Z.i5SZFxUaBawPgNla94Gea8c6HW7EzRKf6czJ9w6uAsq7AA/7Kbi','user','','aatxu4qamyGH92mBtOBjq18KY8JqWJsmHF2W1zTKH5lAnAtDQjoa5cZOOm2Q','2016-07-14 04:03:49','2016-07-14 04:36:04'),(2,'admin','admin@gmail.com','$2y$10$1boaNcw0Xkoj2NymXOM.VemgU.uKCOTTiLiGBQ8fJfwvYUAcJpdjS','user','','hjE1tJ1bM1DywF5JnfVCJc7ITA2s8fw9kd96KPgUMaFF35TyQru7fsz1YH6w','2016-07-14 04:04:34','2016-07-14 04:04:58'),(3,'diego','dlopezo@gmail.com','$2y$10$7QeJ7VoN9vtQ/Q/R83Omre5nT4zr8Frkc/mq2IJ5nwDmqftX.VMuS','user','','GG4ohrNJVf92HEWlYnhSd5mGOj4ZkCD4aPnZrl4qw8Ha8ecAq2xiMnvWfgOO','2016-07-14 05:58:26','2016-07-14 08:14:31'),(4,'julioh','julio.hernandez@delbosquetechnology.com','$2y$10$y/oFgVUOzaXTMmmwLmJtOO9TwiMy2KqPH1AJUXmKBJyAtmp73ipI6','user','',NULL,'2016-07-14 07:35:26','2016-07-14 07:35:26');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-17  0:00:13
