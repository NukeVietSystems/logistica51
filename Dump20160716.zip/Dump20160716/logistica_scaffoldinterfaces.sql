CREATE DATABASE  IF NOT EXISTS `logistica` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `logistica`;
-- MySQL dump 10.13  Distrib 5.5.49, for debian-linux-gnu (i686)
--
-- Host: 127.0.0.1    Database: logistica
-- ------------------------------------------------------
-- Server version	5.5.49-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `scaffoldinterfaces`
--

DROP TABLE IF EXISTS `scaffoldinterfaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scaffoldinterfaces` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `package` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `controller` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `views` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scaffoldinterfaces`
--

LOCK TABLES `scaffoldinterfaces` WRITE;
/*!40000 ALTER TABLE `scaffoldinterfaces` DISABLE KEYS */;
INSERT INTO `scaffoldinterfaces` VALUES (3,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_091430_personas.php','/home/susana-pq/logistica51/app/Persona.php','/home/susana-pq/logistica51/app/Http/Controllers/PersonaController.php','/home/susana-pq/logistica51/resources/views/persona','personas','2016-07-17 00:14:30','2016-07-17 00:14:30'),(7,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_093811_clientas.php','/home/susana-pq/logistica51/app/Clienta.php','/home/susana-pq/logistica51/app/Http/Controllers/ClientaController.php','/home/susana-pq/logistica51/resources/views/clienta','clientas','2016-07-17 00:38:11','2016-07-17 00:38:11'),(8,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_094525_proveedores.php','/home/susana-pq/logistica51/app/Proveedore.php','/home/susana-pq/logistica51/app/Http/Controllers/ProveedoreController.php','/home/susana-pq/logistica51/resources/views/proveedore','proveedores','2016-07-17 00:45:25','2016-07-17 00:45:25'),(11,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_100509_hospedajes.php','/home/susana-pq/logistica51/app/Hospedaje.php','/home/susana-pq/logistica51/app/Http/Controllers/HospedajeController.php','/home/susana-pq/logistica51/resources/views/hospedaje','hospedajes','2016-07-17 01:05:09','2016-07-17 01:05:09'),(12,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_100809_transportes.php','/home/susana-pq/logistica51/app/Transporte.php','/home/susana-pq/logistica51/app/Http/Controllers/TransporteController.php','/home/susana-pq/logistica51/resources/views/transporte','transportes','2016-07-17 01:08:09','2016-07-17 01:08:09'),(13,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_100956_otrosservicios.php','/home/susana-pq/logistica51/app/Otrosservicio.php','/home/susana-pq/logistica51/app/Http/Controllers/OtrosservicioController.php','/home/susana-pq/logistica51/resources/views/otrosservicio','otrosservicios','2016-07-17 01:09:56','2016-07-17 01:09:56'),(14,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_101337_tarifarios.php','/home/susana-pq/logistica51/app/Tarifario.php','/home/susana-pq/logistica51/app/Http/Controllers/TarifarioController.php','/home/susana-pq/logistica51/resources/views/tarifario','tarifarios','2016-07-17 01:13:37','2016-07-17 01:13:37'),(16,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_105121_usuarios.php','/home/susana-pq/logistica51/app/Usuario.php','/home/susana-pq/logistica51/app/Http/Controllers/UsuarioController.php','/home/susana-pq/logistica51/resources/views/usuario','usuarios','2016-07-17 01:51:21','2016-07-17 01:51:21'),(17,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_105617_modificaciontarifarios.php','/home/susana-pq/logistica51/app/Modificaciontarifario.php','/home/susana-pq/logistica51/app/Http/Controllers/ModificaciontarifarioController.php','/home/susana-pq/logistica51/resources/views/modificaciontarifario','modificaciontarifarios','2016-07-17 01:56:17','2016-07-17 01:56:17'),(18,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_105932_contactos.php','/home/susana-pq/logistica51/app/Contacto.php','/home/susana-pq/logistica51/app/Http/Controllers/ContactoController.php','/home/susana-pq/logistica51/resources/views/contacto','contactos','2016-07-17 01:59:32','2016-07-17 01:59:32'),(19,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_16_113631_ticketgastronomicos.php','/home/susana-pq/logistica51/app/Ticketgastronomico.php','/home/susana-pq/logistica51/app/Http/Controllers/TicketgastronomicoController.php','/home/susana-pq/logistica51/resources/views/ticketgastronomico','ticketgastronomicos','2016-07-17 02:36:31','2016-07-17 02:36:31'),(20,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_17_010711_entidads.php','/home/susana-pq/logistica51/app/Entidad.php','/home/susana-pq/logistica51/app/Http/Controllers/EntidadController.php','/home/susana-pq/logistica51/resources/views/entidad','entidads','2016-07-17 04:07:11','2016-07-17 04:07:11'),(21,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_17_012950_centro_medicos.php','/home/susana-pq/logistica51/app/Centro_medico.php','/home/susana-pq/logistica51/app/Http/Controllers/Centro_medicoController.php','/home/susana-pq/logistica51/resources/views/centro_medico','centro_medicos','2016-07-17 04:29:50','2016-07-17 04:29:50'),(22,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_17_013337_especialidads.php','/home/susana-pq/logistica51/app/Especialidad.php','/home/susana-pq/logistica51/app/Http/Controllers/EspecialidadController.php','/home/susana-pq/logistica51/resources/views/especialidad','especialidads','2016-07-17 04:33:37','2016-07-17 04:33:37'),(24,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_17_014331_medicos.php','/home/susana-pq/logistica51/app/Medico.php','/home/susana-pq/logistica51/app/Http/Controllers/MedicoController.php','/home/susana-pq/logistica51/resources/views/medico','medicos','2016-07-17 04:43:31','2016-07-17 04:43:31'),(25,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_17_022300_familiares.php','/home/susana-pq/logistica51/app/Familiare.php','/home/susana-pq/logistica51/app/Http/Controllers/FamiliareController.php','/home/susana-pq/logistica51/resources/views/familiare','familiares','2016-07-17 05:23:01','2016-07-17 05:23:01'),(26,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_17_023336_regimen_comidas.php','/home/susana-pq/logistica51/app/Regimen_comida.php','/home/susana-pq/logistica51/app/Http/Controllers/Regimen_comidaController.php','/home/susana-pq/logistica51/resources/views/regimen_comida','regimen_comidas','2016-07-17 05:33:36','2016-07-17 05:33:36'),(27,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_17_023725_auditores.php','/home/susana-pq/logistica51/app/Auditore.php','/home/susana-pq/logistica51/app/Http/Controllers/AuditoreController.php','/home/susana-pq/logistica51/resources/views/auditore','auditores','2016-07-17 05:37:25','2016-07-17 05:37:25'),(28,'Laravel','/home/susana-pq/logistica51/database/migrations/2016_07_17_025359_reservas.php','/home/susana-pq/logistica51/app/Reserva.php','/home/susana-pq/logistica51/app/Http/Controllers/ReservaController.php','/home/susana-pq/logistica51/resources/views/reserva','reservas','2016-07-17 05:53:59','2016-07-17 05:53:59');
/*!40000 ALTER TABLE `scaffoldinterfaces` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-17  0:00:13
