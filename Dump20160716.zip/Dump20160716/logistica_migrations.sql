CREATE DATABASE  IF NOT EXISTS `logistica` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `logistica`;
-- MySQL dump 10.13  Distrib 5.5.49, for debian-linux-gnu (i686)
--
-- Host: 127.0.0.1    Database: logistica
-- ------------------------------------------------------
-- Server version	5.5.49-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2015_02_09_203406_create_tags_table',1),('2015_02_09_204614_create_user_profiles_table',1),('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2015_02_09_203406_create_tags_table',1),('2015_02_09_204614_create_user_profiles_table',1),('2015_10_31_162633_scaffoldinterfaces',2),('2016_07_13_140053_create_afiliados_table',2),('2016_07_16_071408_books',3),('2016_07_16_071447_julios',3),('2016_07_16_084731_medicossusanas',3),('2016_07_16_091430_personas',4),('2016_07_16_092259_usuarios',5),('2016_07_16_092432_tarifarios',6),('2016_07_16_093140_clientes',7),('2016_07_16_093811_clientas',8),('2016_07_16_094525_proveedores',9),('2016_07_16_095634_hospedajes',10),('2016_07_16_100125_gastronomicos',11),('2016_07_16_100509_hospedajes',12),('2016_07_16_100809_transportes',13),('2016_07_16_100956_otrosservicios',14),('2016_07_16_101337_tarifarios',15),('2016_07_16_102219_gastronomicos',16),('2016_07_16_105121_usuarios',16),('2016_07_16_105617_modificaciontarifarios',17),('2016_07_16_105932_contactos',18),('2016_07_16_113631_ticketgastronomicos',19),('2016_07_17_010711_entidads',20),('2016_07_17_012950_centro_medicos',21),('2016_07_17_013337_especialidads',21),('2016_07_17_014331_medicos',22),('2016_07_17_022300_familiares',23),('2016_07_17_023336_regimen_comidas',24),('2016_07_17_023725_auditores',25),('2016_07_17_025359_reservas',26);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-17  0:00:13
